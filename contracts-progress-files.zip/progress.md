# Requirement progress

Status: todo | in-scope | done. One requirement in-scope at a time.

Contracts: `.claude/tdd/contracts.md` (§3 Contracts + §7 Invariants of plan v2,
extracted verbatim 2026-08-19 — this is what gets passed to architect on every
requirement's plan step).

Backlog source: `docs/specs/2026-08-20-embedding-enrichment-steelthread-v2.md`
§8 (orchestrator/human reference only — never passed to a subagent; the lines
below are the transcription). `depends`/`track` are advisory: the list is
topologically ordered, so picking the next todo is always safe.

- [x] R1  Minimal enrich → text-space `.npz` sidecar (build_node_text text-family + _call_embeddings stub + enrich_embeddings, normalize-on-write, meta; T1–T6)   status: done   <!-- depends: none; track: serial; landed 0ab7da3+e6ca0bb -->
- [x] R2  `semantic_search` MCP tool over the sidecar (register + lazy graph-cached load + cosine + min_score/file_type/top_k + space label + sanitize + absent-sidecar instruction + rendered surface + stale-row; T7–T14)   status: done   <!-- depends: R1; track: serial; landed 9d57482..27afcb5; RT27 (R8) is the blend no-regression guard -->
- [x] R3  Real text embedding backend + batching + query-embed LRU + load-time meta validation + backup manifest (EMBEDDING_BACKENDS, real _call_embeddings, Bifrost/local routing RT4, excluded-backend errors, 0-retry ollama + override, timeout, dim guard, batch sizing, LRU, embeddings.npz in _BACKUP_ARTIFACTS; C5/C9; RT1–RT8, I5/I8/I11)   status: done   <!-- depends: R1; track: serial; landed 2026-08-18 C3.1–C3.4 (b3d5a75..ba1c925) -->
- [ ] R4  Embedding cache + incremental guarantee (two (backend,model) namespaces, sha256(constructed text) keys, atomic writes, corrupt-count, prune pass; C6 §8; RT9–RT12; the "3-file edit ⇒ 3 files of calls" goal)   status: in-scope   <!-- depends: R3; track: parallel-with R5,R6; started 2026-08-18 auto -->
- [ ] R5  Rich deterministic node text construction (label/path/rationale/10 neighbours (-degree,id), rationale-first, 512-cap; rewrites done T1 literal per C2; hosts cache-key trap test RT17; C1/C2 §2; RT13–RT17, I2)   status: todo   <!-- depends: R1; track: parallel-with R4,R6 -->
- [ ] R6  Neo4j tier: shared prop-filter at 4 sites (bool-before-int, allow list[int|float], drop list[dict]) + embedding_code/text props + :Embedded + two CREATE VECTOR INDEX (graceful, non-fatal) + Aura queryNodes manual acceptance (C8 §7; RT18–RT23 + manual, I9/I10/I13)   status: todo   <!-- depends: R1; track: parallel-with R3,R4,R5 -->
- [ ] R7  Second vector space (code model): nomic-embed-code, code_* sidecar, code-node text §2.1, dual-space search merge/interleave/space-label, dual concurrent query embed (C3/C10 §1/§2.1/§5; RT24–RT26, I4)   status: todo   <!-- depends: R3,R5; track: serial -->
- [ ] R8  `query_graph` blend: semantic into _score_query, gated (weight 0 → bit-identical), lexical priority (C7 §6.2; RT27–RT28, I1)   status: todo   <!-- depends: R2,R7; track: serial -->
- [ ] R9  CLI: `graphify embed .`, `extract --embed`, dispatch_command/--help/_FREE_TEXT_CMDS guard, zero-node no-op (C11 §6.3; RT29–RT32)   status: todo   <!-- depends: R1,R3; track: serial -->
