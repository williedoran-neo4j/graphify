# Contracts & Invariants

Extracted verbatim from `docs/specs/2026-08-20-embedding-enrichment-steelthread-v2.md`
(§3 Contracts, §7 Invariants) on 2026-08-19. Cross-cutting — read on EVERY
requirement's plan step. Do not read the full v2 plan for planning purposes;
its §5/§6/§8 are orchestrator/backlog-only and are never passed to a subagent.

---

## 3. Contracts

Contracts the DONE surface locks are restated briefly, marked `[done]`, and
*kept*: every future slice must keep their tests green. NOT-done contracts are
marked `[planned]`.

### C1 — `build_node_text(node) -> str | None` `[done]`

- Text-family node (`document`/`paper`/`rationale`/`concept`) →
  `f"{label}\n{source_file}"`. Deterministic: two calls, byte-identical (I2).
- `image` (and every non-text-family) node → `None`, excluded from every space.
- R5 *extends* this signature with §2's rich construction. This is a
  **contract alteration to a done contract**: R5's rich form replaces the exact
  `"{label}\n{source_file}"` literal, so the done test T1 (which pins that exact
  string) is *rewritten* in R5 — its label-line-first and determinism halves
  survive as guards, its exact-literal half is superseded by C2 below. Flagged
  because it alters a done contract — see R5.

### C2 — Embedded node text (R5) `[planned]`

R5's richer `build_node_text` output, pinned by structure and content, not by an
exact literal (callers consume vectors, not the string):

- **Structure:** (1) label line, (2) a path-qualified source line, (3) a
  rationale line *when present*, (4) up to 10 space-joined neighbour labels.
- **Ordering:** the label line is the *first* line and survives the cap verbatim;
  neighbours appear in `(-degree, id)` order (total tie-break); the cap truncates
  the neighbour tail, never the label.
- **Content (code, §2.1):** includes the neighbour labels (available graph
  structure, no file reads). **Content (text, §2.2):** `rationale` is the
  primary source; falls back to `label` + `source_file` when absent; same
  neighbour augmentation and cap.
- Determinism (I2) is a hard property — the R4 cache never hits without it.

### C3 — Sidecar `graphify-out/embeddings.npz` `[done]` (R7 extends)

`numpy.savez`, sibling to `graph.json`, space-keyed:

```
text_ids  : (N_t,)      unicode array of node ids
text_vecs : (N_t, D)    float32, every row L2-normalized (||v|| == 1.0)
text_meta : json string {model, backend, dim, graphify_version, created_at}
# R7 adds: code_ids, code_vecs, code_meta   (same shape, reserved in the thread)
```

- `D` recorded in `meta.dim`; loaders validate incoming vectors against it and
  refuse to mix dimensions (I5, RT7).
- Stored rows are always unit-norm (I3): cosine is a plain dot product.
- R7 writes the `code_*` group exactly this way, from §2.1 code text.

### C4 — MCP tool surface `semantic_search` `[done]`

Schema verbatim from §6.1, registered in `list_tools` `_tools` and `_handlers`
with the pre-existing `project_path` injection populated (the injection loop
adds the `project_path` input property; `required` stays `["query"]`).

- **Internal result row:** `{id, label, score, space: "text", file_type}` —
  every LLM-derived field already `sanitize_label`d.
- **Rendered caller surface** (the outer contract tests pin): one line per
  result in descending score,
  `"{score:.3f}  [{space}]  {nid}  {label}  ({file_type})"`, e.g.
  `2.000  [text]  n-b-02  Beta embed  (concept)`. Tests pin values and structure
  (fields, order, the `[space]` literal); cosmetic spacing is not itself the
  contract.
- **Absent sidecar:** a normal successful tool result with the literal
  instruction text "No embeddings found for this graph. Run `graphify embed .`
  first." — never an exception (`call_tool` wraps exceptions into
  `"Error executing …"`).
- **Stale row:** a row whose id is absent from the graph renders id-as-label
  with an empty `()` suffix; never raises (I12).
- **Calls to the same graph root:** after one sidecar load, repeat calls render
  from the in-memory copy; no additional disk open (I7).

### C5 — Embedding backend seam `_call_embeddings` `[planned in R3]`

- Signature `(backend, model, inputs: list[str]) -> list[list[float]]`: exactly
  one vector per input, in input order.
- Backends: `ollama` (default) + `openai`; `claude-cli`/`bedrock`/`claude`
  raise an error naming the supported set (never a fall-through 404).
- `ollama` issues zero SDK retries unless `GRAPHIFY_MAX_RETRIES` is set
  explicitly; `GRAPHIFY_API_TIMEOUT` (default 600s) is honored.
- Batch inputs per call at a documented batch size (I11).
- **Dim guard:** a returned vector of the wrong dimension raises rather than
  being stored (I5).
- Defaults: code → `nomic-embed-code`, text → `nomic-embed-text`, both via the
  `openai`-compatible endpoint (`input` payload, `data[].embedding` response).
- Routing: the default `ollama` backend's base URL is the configured local
  gateway (the embedding-specific `OPENAI_BASE_URL`), never a paid cloud
  endpoint — this is the mechanism behind "cost-free and offline," pinned by RT4.
- Callers must never trust provider normalization — the sidecar writer
  re-normalizes (I3).

### C6 — Embedding write-cache `[planned in R4]`

- Two namespaces keyed `(backend, model)` under `graphify-out/cache/`, beside
  the existing `ast/` and `semantic/` kinds (`cache.cache_dir`). Switching the
  code model must not invalidate text-model entries (RT9).
- A cache entry is keyed by `sha256(constructed text)` from §2 — never a source
  file hash. An edit to file A changes the constructed text of a node in file B
  whose neighbour label changed, so that node's entry misses and is rebuilt
  (RT17 — the trap test).
- Re-running `enrich_embeddings` over an unchanged graph issues **zero**
  embedding calls (RT10) — the incremental goal, falling out of the key.
- Follow the existing cache disciplines rather than inventing new ones:
  corrupt-entry counting (a miss, counted, does not raise — RT11) and a prune
  pass mirroring `prune_semantic_cache` so vectors for nodes no longer in the
  graph do not accumulate forever (RT12). Atomic writes.
- Cache entries are write-path only; sidecar reads (C3/C4's memoization) are
  untouched by it.

### C7 — `query_graph` blend `[planned in R8]`

- When no sidecar exists, `_score_query`'s output is **bit-identical** to
  today's (no semantic contribution, blend weight zero). Observable escape
  hatch: `query_graph` at a fixed input renders a single text; every
  before/after comparison must be byte-equal (RT27).
- A semantic hit never displaces a strong lexical hit (I1): an exact-label match
  keeps rank 1 even when a semantic near-miss scores higher (RT28).
- Blend weight deliberately unspecified (open question #2) — gated closed by
  RT27 until measured.

### C8 — Neo4j tier `[planned in R6]`

- A shared prop-filter helper used at **all four** sites (`push_to_neo4j`
  node+edge, `push_to_falkordb` node+edge): a `list` whose members are all
  `int`/`float` survives to the driver (Neo4j stores `LIST<FLOAT>`); `list[dict]`
  and other nesting still dropped; `bool` checked before `int` (I9).
- Vector node properties `embedding_code` / `embedding_text`, populated from the
  same `enrich_embeddings` output the sidecar gets, so the two tiers cannot
  drift (I10).
- A shared `:Embedded` label on every vector-carrying node; **two**
  `CREATE VECTOR INDEX … IF NOT EXISTS` statements, one per space, dimensions
  from `meta.dim`, cosine. Creation is idempotent, skipped gracefully on
  non-Neo4j-5.13+/FalkorDB, and a failed creation does **not** fail the push
  (RT22).
- **Aura acceptance is explicitly not "the push succeeded":** a manual
  `db.index.vector.queryNodes` call returns sensible neighbours (I13).

### C9 — Search core (graph-agnostic seam) `[done]` (R3 adds load-time validation)

- Returns `None` when the sidecar is absent; a list of `{id, score, space}`
  rows otherwise; score-descending; `min_score` exact-value inclusive; cut to
  `top_k` after ranking.
- R3 adds: on load, validate the sidecar's `meta.dim` against
  `text_vecs.shape[1]` and refuse mismatches (I5, RT7).

### C10 — Result schema, two-space `[planned in R7]`

- Every result carries its own `space` (`code` or `text`); no cross-space score
  comparison is ever asserted. After R7, a fixture whose two spaces both have
  rows above `min_score` and inside `top_k` renders both `[code]` and `[text]`
  lines (RT25), each space's rows score-descending within their space.

### C11 — `graphify embed` / `extract --embed` CLI `[planned in R9]`

Per §6.3, hand-rolled (no argparse subparsers): `__main__.py` reads
`sys.argv[1]` and calls `dispatch_command` (`__main__.py:705`), help text as
literal `print` calls.

- `graphify embed .` — standalone re-embed of an existing graph.
- `graphify extract . --embed` — embed as part of extraction, **after** the
  graph is written.
- `embed` is added to `dispatch_command` **and** to the `--help` block; it is
  **not** added to `_FREE_TEXT_CMDS` (`__main__.py:704`), so the universal help
  guard applies — `graphify embed --help` prints help and stops rather than
  running.
- A **zero-node graph → a clear no-op message**, not an error (§10
  `tests/test_embed_cli.py`).

---


---

## 7. Invariants

Hold across every slice; the test guarding each is named.

- **I1 — Additive & reversible.** A graph with no sidecar behaves exactly as
  today; every new code path is a no-op when the sidecar is absent. *Guarded by:
  T12 (done), RT27 (R8).*
- **I2 — Text determinism.** `build_node_text` is a pure function of the graph's
  data; two runs over an unchanged graph produce byte-identical text, or the
  cache never hits. *Guarded by: T2 (done), RT13 (R5).*
- **I3 — Vectors are always L2-normalized on write** (||v|| == 1.0), regardless
  of which provider route produced them — cosine is a plain dot product.
  *Guarded by: T5 (done).*
- **I4 — Spaces are never compared cross-space; every result carries its own
  space.** Cosine between a code vector and a text vector is meaningless.
  *Guarded by: T10 (done), RT25 (R7).*
- **I5 — Dimension consistency.** Loaded/returned vectors are validated against
  `meta.dim`; mixing dimensions is refused. *Guarded by: T6 (done), RT7 (R3).*
- **I6 — Labels are always sanitized.** Every LLM-derived field in tool output
  goes through `sanitize_label`. *Guarded by: T11 (done).*
- **I7 — Lazy vector load.** A server that never receives a `semantic_search`
  call never opens the `.npz`; the loaded sidecar is cached on the graph object.
  *Guarded by: T14 (done).*
- **I8 — Sidecar is a first-class artifact.** `embeddings.npz` is in
  `export._BACKUP_ARTIFACTS` because it is not regenerable without a re-embed.
  *Guarded by: RT8 (R3).*
- **I9 — `bool` before `int`** in every numeric-list membership test in the prop
  filter (`bool` subclasses `int`). *Guarded by: RT20 (R6).*
- **I10 — Neo4j and sidecar cannot drift** — both tiers are populated from the
  same `enrich_embeddings` output. *Guarded by: RT23 (R6).*
- **I11 — Batch discipline.** Embedding calls are batched at a documented size;
  wall-clock is dominated by batches, never one HTTP round-trip per node.
  *Guarded by: RT5 (R3).*
- **I12 — Stale sidecar rows never raise.** A row whose id is absent from the
  graph renders id-as-label with an empty `()` suffix. *Guarded by: the stale-row
  test in `tests/test_embed_search.py` (done).*
- **I13 — Neo4j vectors must be *queryable*, not just pushed.** A round-trip
  that does not answer `db.index.vector.queryNodes` is a silent failure.
  *Guarded by: manual Aura acceptance (R6); a successful push alone does not
  count.*

---

